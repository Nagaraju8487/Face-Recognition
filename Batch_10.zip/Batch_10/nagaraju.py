import face_recognition
import cv2
import numpy as np
import csv
import os
from datetime import datetime

video_capture = cv2.VideoCapture(0)

# Load known faces from 'aiml_a' and 'aiml_b' folders
known_faces = {'aiml_a': [], 'aiml_b': []}
known_names = {'aiml_a': [], 'aiml_b': []}

def load_images_from_folder(folder_path, group_key):
    for filename in os.listdir(folder_path):
        img_path = os.path.join(folder_path, filename)
        image = face_recognition.load_image_file(img_path)
        encoding = face_recognition.face_encodings(image)
        if encoding:
            known_faces[group_key].append(encoding[0])
            known_names[group_key].append(os.path.splitext(filename)[0])  # use file name as person name

# Load images for both groups
load_images_from_folder('known_faces/aiml_a', 'aiml_a')
load_images_from_folder('known_faces/aiml_b', 'aiml_b')

# Prepare attendance tracking and CSV file writing
current_date = datetime.now().strftime("%Y-%m-%d")
csv_files = {
    'aiml_a': open(f"{current_date}_aiml_a.csv", "w+", newline=""),
    'aiml_b': open(f"{current_date}_aiml_b.csv", "w+", newline="")
}
csv_writers = {
    'aiml_a': csv.writer(csv_files['aiml_a']),
    'aiml_b': csv.writer(csv_files['aiml_b'])
}

# Initialize attendance tracking to avoid duplicate entries in CSV
recognized_faces = {'aiml_a': set(), 'aiml_b': set()}

# Set a threshold for face recognition accuracy
face_distance_threshold = 0.6  # Lower values increase accuracy, but might miss matches

while True:
    _, frame = video_capture.read()
    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
    rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

    # Recognize faces
    face_locations = face_recognition.face_locations(rgb_small_frame)
    face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

    for face_encoding, face_location in zip(face_encodings, face_locations):
        found_match = False
        best_match_name = None
        best_match_group = None
        best_match_distance = face_distance_threshold  # Only accept matches below this distance

        # Loop through each group to find the closest match
        for group_key in ['aiml_a', 'aiml_b']:
            face_distances = face_recognition.face_distance(known_faces[group_key], face_encoding)

            if face_distances.size > 0:
                min_distance_index = np.argmin(face_distances)
                min_distance = face_distances[min_distance_index]

                if min_distance < best_match_distance:
                    best_match_name = known_names[group_key][min_distance_index]
                    best_match_group = group_key
                    best_match_distance = min_distance
                    found_match = True

        # If a match is found, mark attendance and display name
        if found_match and best_match_name and best_match_name not in recognized_faces[best_match_group]:
            # Add name to recognized faces for tracking attendance
            recognized_faces[best_match_group].add(best_match_name)
            current_time = datetime.now().strftime("%H:%M:%S")
            csv_writers[best_match_group].writerow([best_match_name, current_time])  # Record attendance

            # Draw rectangle and name
            top, right, bottom, left = [v * 4 for v in face_location]
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, f"{best_match_name} Present", (left, bottom + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255, 0, 0), 2)
        
        # If no match was found, label as "Unknown Person"
        elif not found_match:
            top, right, bottom, left = [v * 4 for v in face_location]
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
            cv2.putText(frame, "Unknown Person", (left, bottom + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2)

    # Display the result
    cv2.imshow("Camera", frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


# Release resources
video_capture.release()
cv2.destroyAllWindows()
for f in csv_files.values():
    f.close()
